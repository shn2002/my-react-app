import React  from 'react'
import '../static/style/components/footer.css'

const Footer = () => (
 <div className="footer-div">
     <div>System uses React+Node+Ant Desigin</div>
     <div>Developed by Henian Shan</div>
 </div>

)
export default Footer